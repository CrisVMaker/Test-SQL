--read me
--1. dentro del paquete de carpetas se deja un archivo de excel que contiene una base de datos de guia para la busqueda. 
--2. la ejecucion de sp principal "[dbo].[ConsultaPermisos]", se debe hacer especificando el centro de costo o el id de la sucursal y como
-----segundo parametro el id del usuario


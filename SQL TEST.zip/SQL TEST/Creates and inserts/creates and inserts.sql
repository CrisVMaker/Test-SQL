
use Testsql

----tablas principales 
		create  table  users
(id_user int not null primary key, [user]varchar(25) unique)

create  table  roles
(idRol int not null primary key, [rol_name]varchar(25) unique)


create table Permission
([permission_name] varchar(50) primary key)


create table centro_costo
(id_ceco int not null primary key ,  centro_costo_name varchar(50) )

create table sucursales
(id_sucursal int not null primary key , sucursal_name varchar(50))


----tablas de relaciones 
create  table rel_roles_users 
(id_user int not null  , 
idRol int 
constraint pk_id primary key ( id_user, idRol)   
CONSTRAINT fk_rel_roles_users_id FOREIGN KEY (id_user) REFERENCES users (id_user),
CONSTRAINT fk_rel_roles_users_idrol FOREIGN KEY (idRol) REFERENCES roles (idRol))

create table rel_centro_costos_sucuarsales
(id_sucursal int ,  
 id_ceco int
constraint pk_rel_ceco_suc primary key (id_sucursal , id_ceco)   
CONSTRAINT fk_rel_ceco_suc_id_suc FOREIGN KEY (id_sucursal) REFERENCES sucursales (id_sucursal),
CONSTRAINT fk_rel_ceco_suc_id_ce FOREIGN KEY (id_ceco) REFERENCES centro_costo (id_ceco))



----tablas de control

create table UserRecord
(user_record_id  int not null primary key , 
id_ceco int, 
id_sucursal int, 
id_user int
CONSTRAINT fk_user_recordid_ceco FOREIGN KEY (id_ceco) REFERENCES centro_costo (id_ceco),
CONSTRAINT fk_user_recordid_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursales (id_sucursal),
CONSTRAINT fk_user_recordid_idUser FOREIGN KEY (id_user) REFERENCES users (id_user))

create table rolRecord
(role_record_id  int not null primary key, 
id_ceco int, 
id_sucursal int, 
idRol int
CONSTRAINT fk_user_rolRecordid_ceco FOREIGN KEY (id_ceco) REFERENCES centro_costo (id_ceco),
CONSTRAINT fk_user_rolRecordid_sucursal FOREIGN KEY (id_sucursal) REFERENCES sucursales (id_sucursal),
CONSTRAINT fk_user_rolRecordid_rol FOREIGN KEY (idRol) REFERENCES roles (idRol))

create table PermiUser
(id_user int ,
[permission_name] varchar(50)
constraint pk_idper_user primary key ( id_user, [permission_name])   
CONSTRAINT fk_rel_PermiUser_id_user FOREIGN KEY (id_user) REFERENCES users (id_user),
CONSTRAINT fk_rel_PermiUser_permission FOREIGN KEY ([permission_name]) REFERENCES Permission ([permission_name]))


create table PermiRol
(role_id int ,
[permission_name] varchar(50)
constraint pk_idper_rol primary key (role_id , [permission_name])   
CONSTRAINT fk_rel_PermiRol_role_id FOREIGN KEY (role_id) REFERENCES roles (idRol),
CONSTRAINT fk_rel_PermiRol_permission FOREIGN KEY ([permission_name]) REFERENCES Permission ([permission_name]))


create table PermiUserRecord
(user_record_id int,
[permission_name] varchar(50)
constraint pk_PermiUserRecord primary key (user_record_id , [permission_name])   
CONSTRAINT fk_PermiUserRecord_user_recor FOREIGN KEY (user_record_id) REFERENCES UserRecord (user_record_id ),
CONSTRAINT fk_PermiUserRecord_permission FOREIGN KEY ([permission_name]) REFERENCES Permission ([permission_name]))

create table PermiRolRecord
(role_record_id int,
[permission_name] varchar(50)
constraint pk_PermiRolRecord primary key (role_record_id , [permission_name])   
CONSTRAINT fk_PermiRolRecord_role_record FOREIGN KEY (role_record_id) REFERENCES rolRecord (role_record_id),
CONSTRAINT fk_PermiRolRecord_permission FOREIGN KEY ([permission_name]) REFERENCES Permission ([permission_name]))










----insercion datos tablas principales 
insert into users
values (1,'JuanP�rez001234'),
(2,'AnaG�mez001234'),
(3,'CarlosL�pez001234'),
(4,'LauraMart�nez005678'),
(5,'JavierS�nchez005678'),
(6,'MartaRodr�guez001234'),
(7,'PedroMart�nez001235'),
(8,'ElisaFern�ndez005678'),
(9,'LuisRam�rez001234'),
(10,'PatriciaGonz�lez005678'),
(11,'RobertoTorres001234'),
(12,'CarmenMorales005678'),
(13,'FranciscoP�rez001234'),
(14,'SusanaFern�ndez005678'),
(15,'EnriqueGonz�lez001234'),
(16,'IsabelMart�nez005678'),
(17,'ManuelS�nchez001234'),
(18,'SandraL�pez005678'),
(19,'VicenteTorres001234'),
(20,'MartaGarc�a005678'),
(21,'JavierMart�nez001234'),
(22,'LuisFern�ndez005678'),
(23,'CarmenP�rez001234'),
(24,'AlbertoS�nchez005678'),
(25,'Jos�Ram�rez001234'),
(26,'PatriciaG�mez005678'),
(27,'CarlosMorales001234'),
(28,'EnriqueRodr�guez005678'),
(29,'ElenaTorres001234'),
(30,'SergioMart�nez005678'),
(31,'RosaFern�ndez001234'),
(32,'LuisP�rez005678'),
(33,'AntonioGonz�lez001234'),
(34,'IsabelS�nchez005678'),
(35,'FranciscoMorales001234'),
(36,'MartaRodr�guez005678'),
(37,'PedroMart�nez001234'),
(38,'EnriqueG�mez005678'),
(39,'LauraS�nchez001234'),
(40,'PatriciaFern�ndez005678'),
(41,'Ra�lP�rez001234'),
(42,'JavierRodr�guez005678'),
(43,'CarmenTorres001234'),
(44,'LauraMorales005678'),
(45,'RicardoMart�nez001234'),
(46,'SergioS�nchez005678'),
(47,'PatriciaL�pez001234'),
(48,'AlfredoGonz�lez005678'),
(49,'Jos�Torres001234'),
(50,'IsabelP�rez005678'),
(51,'TeresaRodr�guez001234')


insert into  roles
values(1,	'Desarrollador Backend'),
(2,	'Desarrolladora Frontend'),
(3,	'L�der de Proyecto'),
(4,	'Analista de Datos'),
(5,	'Desarrollador Full Stack'),
(6,	'Tester de Software'),
(7,	'DevOps'),
(8,	'Admin de Base de Datos'),
(9,	'Desarrolladora Full Stack')


insert into Permission
values 
('lectura'),
('escritura'),
('eliminacion'),
('edicion')


insert into centro_costo
values
(202530,	'Equipo_desarrollo'),
(354555,	'Equipo_lideres'),
(606065,	'Equipo_desarrollo_VIP'),
(202531,	'Equipo_dba')


insert into sucursales
values
(1,'Sur'),
(2,'Norte'),
(3,'Centro')


insert into rel_centro_costos_sucuarsales
values 
('2',202531), 
('1',202531),
('3',202531),
('1',354555),
('3',354555),
('2',354555),
('1',202530),
('3',202530),
('2',202530),
('2',606065),
('1',606065),
('3',606065)

insert into rel_roles_users
values (1,1),
(2,2),
(3,3),
(6,6),
(7,7),
(9,1),
(11,3),
(13,6),
(15,7),
(17,1),
(19,3),
(21,6),
(23,7),
(25,1),
(27,3),
(29,6),
(31,7),
(33,1),
(35,3),
(37,6),
(39,7),
(41,1),
(43,3),
(45,6),
(47,7),
(49,1),
(51,3),
(4,4),
(5,5),
(8,8),
(10,2),
(12,4),
(14,9),
(16,8),
(18,2),
(20,4),
(22,5),
(24,8),
(26,2),
(28,4),
(30,9),
(32,8),
(34,2),
(36,4),
(38,5),
(40,8),
(42,2),
(44,4),
(46,9),
(48,8),
(50,2)

insert into UserRecord
values (	1	,	202531	,	2	,	8	),
(	2	,	202531	,	1	,	16	),
(	3	,	202531	,	3	,	24	),
(	4	,	202531	,	2	,	32	),
(	5	,	202531	,	1	,	40	),
(	6	,	202531	,	3	,	48	),
(	7	,	354555	,	1	,	4	),
(	8	,	354555	,	3	,	12	),
(	9	,	354555	,	2	,	20	),
(	10	,	354555	,	1	,	28	),
(	11	,	354555	,	3	,	36	),
(	12	,	354555	,	2	,	44	),
(	13	,	202530	,	1	,	1	),
(	14	,	202530	,	3	,	9	),
(	15	,	202530	,	2	,	17	),
(	16	,	202530	,	1	,	25	),
(	17	,	202530	,	3	,	33	),
(	18	,	202530	,	2	,	41	),
(	19	,	202530	,	1	,	49	),
(	20	,	606065	,	2	,	5	),
(	21	,	606065	,	1	,	22	),
(	22	,	202530	,	2	,	2	),
(	23	,	202530	,	1	,	10	),
(	24	,	202530	,	3	,	18	),
(	25	,	202530	,	2	,	26	),
(	26	,	202530	,	1	,	34	),
(	27	,	202530	,	3	,	42	),
(	28	,	202530	,	2	,	50	),
(	29	,	606065	,	2	,	14	),
(	30	,	606065	,	3	,	30	),
(	31	,	606065	,	2	,	38	),
(	32	,	606065	,	1	,	46	),
(	33	,	606065	,	1	,	7	),
(	34	,	606065	,	3	,	15	),
(	35	,	606065	,	2	,	23	),
(	36	,	606065	,	1	,	31	),
(	37	,	606065	,	3	,	39	),
(	38	,	606065	,	2	,	47	),
(	39	,	354555	,	3	,	3	),
(	40	,	354555	,	2	,	11	),
(	41	,	354555	,	1	,	19	),
(	42	,	354555	,	3	,	27	),
(	43	,	354555	,	2	,	35	),
(	44	,	354555	,	1	,	43	),
(	45	,	354555	,	3	,	51	),
(	46	,	202530	,	3	,	6	),
(	47	,	202530	,	1	,	13	),
(	48	,	202530	,	3	,	21	),
(	49	,	202530	,	2	,	29	),
(	50	,	202530	,	1	,	37	),
(	51	,	202530	,	3	,	45	)


insert into rolRecord
values (	1	,	202531	,	2	,	8	),
(	2	,	202531	,	1	,	8	),
(	3	,	202531	,	3	,	8	),
(	4	,	354555	,	1	,	4	),
(	5	,	354555	,	3	,	4	),
(	6	,	354555	,	2	,	4	),
(	7	,	202530	,	1	,	1	),
(	8	,	202530	,	3	,	1	),
(	9	,	202530	,	2	,	1	),
(	10	,	606065	,	2	,	5	),
(	11	,	606065	,	1	,	5	),
(	12	,	202530	,	2	,	2	),
(	13	,	202530	,	1	,	2	),
(	14	,	202530	,	3	,	2	),
(	15	,	606065	,	2	,	9	),
(	16	,	606065	,	3	,	9	),
(	17	,	606065	,	1	,	9	),
(	18	,	606065	,	1	,	7	),
(	19	,	606065	,	3	,	7	),
(	20	,	606065	,	2	,	7	),
(	21	,	354555	,	3	,	3	),
(	22	,	354555	,	2	,	3	),
(	23	,	354555	,	1	,	3	),
(	24	,	202530	,	3	,	6	),
(	25	,	202530	,	1	,	6	),
(	26	,	202530	,	2	,	6	)




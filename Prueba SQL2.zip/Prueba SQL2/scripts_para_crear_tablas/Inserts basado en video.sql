
----------------Ejemplo 1
--exec [revisa_permisos] 28,1
--exec Inserta_permisos_permiRole  6,3,3,0,2
--exec Inserta_permisos_permiRoleRecord  6,6,3,34,1
--exec Inserta_permisos_permiUser  1,7,2,1
--exec Inserta_permisos_permiUserRecord  1,6,1,34,0

----------------Ejemplo 2 
--exec [revisa_permisos] 50,1
--exec Inserta_permisos_permiRole  2,10,1,1,2
--exec Inserta_permisos_permiRoleRecord  2,5,1,20,0


Select * from  PermiRole 
Select * from permiroleRecord
Select * from PermiUser 
Select * from permiUserRecord

--truncate table PermiRole
--truncate table permiroleRecord
--truncate table Permiuser
--truncate table permiUserRecord
--delete from  PermiRole where id_perol = 12

-----------create extra para la relacion de usuario y rol
create  table rel_user_rol 
(id_user int not null  , 
id_role int 
constraint pk_id primary key ( id_user, id_role)   
CONSTRAINT fk_rel_roles_users_id FOREIGN KEY (id_user) REFERENCES [user] (id_user),
CONSTRAINT fk_rel_roles_users_idrol FOREIGN KEY (id_role) REFERENCES [role] (id_role))

----------------select * from rel_user_rol
insert into rel_user_rol 
values (50,2),(28,6)


-------------------select * from UserCompany 
insert into UserCompany
values (28,3,1),(11,2,1),(50,1,1)


------------------select * from EntityCatalog 
INSERT INTO EntityCatalog (
    entit_name, 
    entit_descrip, 
    entit_active, 
    entit_config
)
VALUES
('User', 'Modelo que representa el perfil de usuario en el sistema', 1, 'N/A'),
('Rol', 'Modelo que representa los roles existentes en la compa�ia', 1, 'N/A'),
('Clients', 'Modelo que representa los clientes que se tienen', 1, 'N/A'),
('Permision', 'Modelo que representa los permisos', 1, 'N/A'),
('Company', 'Modelo que representa las sucursales', 1, 'N/A{'),
('BranchOffice', 'Modelo que representa las oficinas actuales', 1, 'N/A'),
('CostCenter', 'Modelo que representa los centros de costo existentes', 1, 'N/A'),
('Customer', 'Modelo que representa los datos de un cliente en el sistema', 1, 'N/A'),
('Suppliers', 'Modelo que representa los proveedores de la compa�ia', 0, 'N/A'),
('Payroll', 'Modelo que permite ver la nomina de los empleados', 1, 'N/A');

---------------select * from Permisos
INSERT INTO   Permission (
    name, 
    description, 
    can_create, 
    can_read, 
    can_update, 
    can_delete, 
    can_import, 
    can_export
)
VALUES
('Permiso 1', 'Permiso con todos los permisos activos', 1, 1, 1, 1, 1, 1),
('Permiso 2', 'Permiso con solo creaci�n activa', 1, 0, 0, 0, 0, 0),
('Permiso 3', 'Permiso con solo lectura activa', 0, 1, 0, 0, 0, 0),
('Permiso 4', 'Permiso con solo modificaci�n activa', 0, 0, 1, 0, 0, 0),
('Permiso 5', 'Permiso con solo eliminaci�n activa', 0, 0, 0, 1, 0, 0),
('Permiso 6', 'Permiso con solo importacion activa', 0, 0, 0, 0, 1, 0),
('Permiso 7', 'Permiso con importacion y exportacion activa', 0, 0, 0, 0, 1, 1),
('Permiso 8', 'Permiso con solo exportacion activa', 0, 0, 0, 0, 0, 1),
('Permiso 9', 'Permiso con creaci�n y lectura activas', 1, 1, 0, 0, 0, 0),
('Permiso 10', 'Permiso con creaci�n y modificaci�n activas', 1, 0, 1, 0, 0, 0),
('Permiso 11', 'Permiso con creaci�n y eliminaci�n activas', 1, 0, 0, 1, 0, 0),
('Permiso 12', 'Permiso con creaci�n y importacion activas', 1, 0, 0, 0, 1, 0),
('Permiso 13', 'Permiso con creaci�n y exportacion activas', 1, 0, 0, 0, 0, 1),
('Permiso 14', 'Permiso con lectura y modificaci�n activas', 0, 1, 1, 0, 0, 0),
('Permiso 15', 'Permiso con lectura y eliminaci�n activas', 0, 1, 0, 1, 0, 0),
('Permiso 16', 'Permiso con lectura y importacion activas', 0, 1, 0, 0, 1, 0),
('Permiso 17', 'Permiso con lectura y exportacion activas', 0, 1, 0, 0, 0, 1),
('Permiso 18', 'Permiso con modificaci�n y eliminaci�n activas', 0, 0, 1, 1, 0, 0),
('Permiso 19', 'Permiso con modificaci�n y importacion activas', 0, 0, 1, 0, 1, 0),
('Permiso 20', 'Permiso con modificaci�n y exportacion activas', 0, 0, 1, 0, 0, 1),
('Permiso 21', 'Permiso con creaci�n, lectura y modificaci�n activas', 1, 1, 1, 0, 0, 0),
('Permiso 22', 'Permiso con creaci�n, lectura y eliminaci�n activas', 1, 1, 0, 1, 0, 0),
('Permiso 23', 'Permiso con creaci�n, lectura y importacion activas', 1, 1, 0, 0, 1, 0),
('Permiso 24', 'Permiso con creaci�n, lectura y exportacion activas', 1, 1, 0, 0, 0, 1),
('Permiso 25', 'Permiso con creaci�n, modificaci�n y eliminaci�n activas', 1, 0, 1, 1, 0, 0),
('Permiso 26', 'Permiso con lectura, modificaci�n y eliminaci�n activas', 0, 1, 1, 1, 0, 0),
('Permiso 27', 'Permiso con lectura, modificaci�n y importacion activas', 0, 1, 1, 0, 1, 0),
('Permiso 28', 'Permiso con lectura, modificaci�n y exportacion activas', 0, 1, 1, 0, 0, 1),
('Permiso 29', 'Permiso con todos los permisos menos importaci�n', 1, 1, 1, 1, 0, 1),
('Permiso 30', 'Permiso con todos los permisos menos exportaci�n', 1, 1, 1, 1, 1, 0),
('Permiso 31', 'Permiso con creaci�n y exportaci�n activas', 1, 0, 0, 0, 0, 1),
('Permiso 32', 'Permiso con lectura y exportaci�n activas', 0, 1, 0, 0, 0, 1),
('Permiso 33', 'Permiso con modificaci�n y exportaci�n activas', 0, 0, 1, 0, 0, 1),
('Permiso 34', 'Permiso con eliminaci�n y exportaci�n activas', 0, 0, 0, 1, 0, 1),
('Permiso 35', 'Permiso con creaci�n, lectura y exportaci�n activas', 1, 1, 0, 0, 0, 1),
('Permiso 36', 'Permiso con creaci�n, modificaci�n y exportaci�n activas', 1, 0, 1, 0, 0, 1),
('Permiso 37', 'Permiso con creaci�n, eliminaci�n y exportaci�n activas', 1, 0, 0, 1, 0, 1),
('Permiso 38', 'Permiso con lectura, modificaci�n y exportaci�n activas', 0, 1, 1, 0, 0, 1),
('Permiso 39', 'Permiso con lectura, eliminaci�n y exportaci�n activas', 0, 1, 0, 1, 0, 1),
('Permiso 40', 'Permiso con modificaci�n, eliminaci�n y exportaci�n activas', 0, 0, 1, 1, 0, 1),
('Permiso 41', 'Permiso con creaci�n, lectura, modificaci�n y exportaci�n activas', 1, 1, 1, 0, 0, 1),
('Permiso 42', 'Permiso con creaci�n, lectura, eliminaci�n y exportaci�n activas', 1, 1, 0, 1, 0, 1),
('Permiso 43', 'Permiso con creaci�n, modificaci�n, eliminaci�n y exportaci�n activas', 1, 0, 1, 1, 0, 1),
('Permiso 44', 'Permiso con lectura, modificaci�n, eliminaci�n y exportaci�n activas', 0, 1, 1, 1, 0, 1),
('Permiso 45', 'Permiso con todos los permisos menos exportaci�n e importaci�n', 1, 1, 1, 1, 0, 0),
('Permiso 46', 'Permiso con solo creaci�n e importaci�n', 1, 0, 0, 0, 1, 0),
('Permiso 47', 'Permiso con solo lectura e importaci�n', 0, 1, 0, 0, 1, 0),
('Permiso 48', 'Permiso con solo modificaci�n e importaci�n', 0, 0, 1, 0, 1, 0),
('Permiso 49', 'Permiso con solo eliminaci�n e importaci�n', 0, 0, 0, 1, 1, 0),
('Permiso 50', 'Permiso con creaci�n, lectura e importaci�n', 1, 1, 0, 0, 1, 0),
('Permiso 51', 'Permiso con creaci�n, modificaci�n e importaci�n', 1, 0, 1, 0, 1, 0),
('Permiso 52', 'Permiso con creaci�n, eliminaci�n e importaci�n', 1, 0, 0, 1, 1, 0),
('Permiso 53', 'Permiso con lectura, modificaci�n e importaci�n', 0, 1, 1, 0, 1, 0),
('Permiso 54', 'Permiso con lectura, eliminaci�n e importaci�n', 0, 1, 0, 1, 1, 0),
('Permiso 55', 'Permiso con modificaci�n, eliminaci�n e importaci�n', 0, 0, 1, 1, 1, 0),
('Permiso 56', 'Permiso con creaci�n, lectura, modificaci�n e importaci�n', 1, 1, 1, 0, 1, 0),
('Permiso 57', 'Permiso con creaci�n, lectura, eliminaci�n e importaci�n', 1, 1, 0, 1, 1, 0),
('Permiso 58', 'Permiso con creaci�n, modificaci�n, eliminaci�n e importaci�n', 1, 0, 1, 1, 1, 0),
('Permiso 59', 'Permiso con lectura, modificaci�n, eliminaci�n e importaci�n', 0, 1, 1, 1, 1, 0),
('Permiso 60', 'Permiso con todos los permisos menos importaci�n', 1, 1, 1, 1, 0, 0),
('Permiso 61', 'Permiso con todos los permisos', 1, 1, 1, 1, 1, 1),
('Permiso 62', 'Permiso con todos los permisos menos exportaci�n', 1, 1, 1, 1, 1, 0),
('Permiso 63', 'Permiso con todos los permisos menos importaci�n', 1, 1, 1, 1, 0, 1),
('Permiso 64', 'Permiso con todos los permisos menos importaci�n y exportaci�n', 1, 1, 1, 1, 0, 0),
('Permiso 65', 'Permiso con todos los permisos activos y exportaci�n activada', 1, 1, 1, 1, 0, 1);




-------------------select * from [User]

INSERT INTO [User] (
    user_username, 
    user_password, 
    user_email, 
    user_phone, 
    user_is_admin, 
    user_is_active
)
VALUES
('johndoe', 'hashedpassword123', 'johndoe@example.com', '+1 234 567 8901', 0, 1),
('janedoe', 'hashedpassword456', 'janedoe@example.com', '+1 234 567 8902', 1, 1),
('michael123', 'hashedpassword789', 'michael123@example.com', '+1 234 567 8903', 0, 1),
('sarasmith', 'hashedpassword321', 'sarasmith@example.com', '+1 234 567 8904', 0, 1),
('davidjones', 'hashedpassword654', 'davidjones@example.com', '+1 234 567 8905', 1, 1),
('alicewilliams', 'hashedpassword987', 'alicewilliams@example.com', '+1 234 567 8906', 0, 1),
('robertbrown', 'hashedpassword159', 'robertbrown@example.com', '+1 234 567 8907', 1, 1),
('charliegreen', 'hashedpassword753', 'charliegreen@example.com', '+1 234 567 8908', 0, 1),
('oliviagrey', 'hashedpassword369', 'oliviagrey@example.com', '+1 234 567 8909', 0, 1),
('liamscott', 'hashedpassword741', 'liamscott@example.com', '+1 234 567 8910', 1, 1),
('isabellamartin', 'hashedpassword258', 'isabellamartin@example.com', '+1 234 567 8911', 0, 1),
('jameswhite', 'hashedpassword852', 'jameswhite@example.com', '+1 234 567 8912', 1, 1),
('lucasblack', 'hashedpassword963', 'lucasblack@example.com', '+1 234 567 8913', 0, 1),
('mariawilliams', 'hashedpassword4567', 'mariawilliams@example.com', '+1 234 567 8914', 0, 1),
('danieladams', 'hashedpassword134', 'danieladams@example.com', '+1 234 567 8915', 1, 1),
('emilyyoung', 'hashedpassword246', 'emilyyoung@example.com', '+1 234 567 8916', 0, 1),
('ethanjackson', 'hashedpassword888', 'ethanjackson@example.com', '+1 234 567 8917', 0, 1),
('avaallen', 'hashedpassword111', 'avaallen@example.com', '+1 234 567 8918', 1, 1),
('jacksonlee', 'hashedpassword999', 'jacksonlee@example.com', '+1 234 567 8919', 0, 1),
('matthewking', 'hashedpassword777', 'matthewking@example.com', '+1 234 567 8920', 1, 1),
('ellaevans', 'hashedpassword222', 'ellaevans@example.com', '+1 234 567 8921', 0, 1),
('joshuafox', 'hashedpassword345', 'joshuafox@example.com', '+1 234 567 8922', 1, 1),
('ameliadavis', 'hashedpassword6543', 'ameliadavis@example.com', '+1 234 567 8923', 0, 1),
('jacobwright', 'hashedpassword8765', 'jacobwright@example.com', '+1 234 567 8924', 1, 1),
('madisonclark', 'hashedpassword1357', 'madisonclark@example.com', '+1 234 567 8925', 0, 1),
('williammoore', 'hashedpassword2468', 'williammoore@example.com', '+1 234 567 8926', 1, 1),
('oliviaanderson', 'hashedpassword3579', 'oliviaanderson@example.com', '+1 234 567 8927', 0, 1),
('henryhernandez', 'hashedpassword4680', 'henryhernandez@example.com', '+1 234 567 8928', 1, 1),
('lucybaker', 'hashedpassword5791', 'lucybaker@example.com', '+1 234 567 8929', 0, 1),
('leahperez', 'hashedpassword6802', 'leahperez@example.com', '+1 234 567 8930', 1, 1),
('noahmiller', 'hashedpassword7913', 'noahmiller@example.com', '+1 234 567 8931', 0, 1),
('gracehill', 'hashedpassword9034', 'gracehill@example.com', '+1 234 567 8932', 1, 1),
('adamsmith', 'hashedpassword1359', 'adamsmith@example.com', '+1 234 567 8933', 0, 1),
('avajohnson', 'hashedpassword2460', 'avajohnson@example.com', '+1 234 567 8934', 1, 1),
('benjaminwood', 'hashedpassword3571', 'benjaminwood@example.com', '+1 234 567 8935', 0, 1),
('jacksonmartin', 'hashedpassword4682', 'jacksonmartin@example.com', '+1 234 567 8936', 1, 1),
('harpermoore', 'hashedpassword5793', 'harpermoore@example.com', '+1 234 567 8937', 0, 1),
('jakebrown', 'hashedpassword6804', 'jakebrown@example.com', '+1 234 567 8938', 1, 1),
('chloewilson', 'hashedpassword7915', 'chloewilson@example.com', '+1 234 567 8939', 0, 1),
('gracejones', 'hashedpassword9026', 'gracejones@example.com', '+1 234 567 8940', 1, 1),
('elijahhernandez', 'hashedpassword0246', 'elijahhernandez@example.com', '+1 234 567 8941', 0, 1),
('noahmartinez', 'hashedpassword1350', 'noahmartinez@example.com', '+1 234 567 8942', 1, 1),
('lilyanderson', 'hashedpassword2461', 'lilyanderson@example.com', '+1 234 567 8943', 0, 1),
('jaredroberts', 'hashedpassword3572', 'jaredroberts@example.com', '+1 234 567 8944', 1, 1),
('rebeccawilson', 'hashedpassword4683', 'rebeccawilson@example.com', '+1 234 567 8945', 0, 1),
('scarlettlee', 'hashedpassword5794', 'scarlettlee@example.com', '+1 234 567 8946', 1, 1),
('thomassmith', 'hashedpassword6805', 'thomassmith@example.com', '+1 234 567 8947', 0, 1),
('alexisjohnson', 'hashedpassword7916', 'alexisjohnson@example.com', '+1 234 567 8948', 1, 1),
('evanscarson', 'hashedpassword9027', 'evanscarson@example.com', '+1 234 567 8949', 0, 1),
('hannahmiller', 'hashedpassword0138', 'hannahmiller@example.com', '+1 234 567 8950', 1, 1),
('oliviakim', 'hashedpassword1351', 'oliviakim@example.com', '+1 234 567 8951', 0, 1);




------------------Select * from  Role

INSERT INTO Role (
    company_id, 
    role_name, 
    role_code, 
    role_description, 
    role_active
)
VALUES
(1, 'Director de Tecnolog�a', 'DT001', 'Responsable de la estrategia tecnol�gica y supervisi�n de proyectos de TI.', 1),
(1, 'Gerente de Operaciones', 'GO001', 'Encargado de la gesti�n y supervisi�n de las operaciones diarias de la empresa.', 1),
(2, 'Director de Marketing', 'DM001', 'Encargado de la planificaci�n y ejecuci�n de estrategias de marketing a nivel global.', 1),
(2, 'Gerente Financiero', 'GF001', 'Responsable de la gesti�n financiera, presupuestos, an�lisis de costos y reportes financieros.', 1),
(3, 'Coordinador de Proyectos', 'CP001', 'Gesti�n y supervisi�n de proyectos a trav�s de su ciclo de vida, asegurando que se cumplan los objetivos.', 1),
(3, 'Asesor Comercial', 'AC001', 'Responsable de la venta de productos y servicios, manejo de clientes y cierre de negociaciones.', 1),
(4, 'Director de Ventas', 'DV001', 'Encargado de la estrategia y supervisi�n del equipo de ventas, incluyendo la creaci�n de relaciones con clientes clave.', 1),
(4, 'Jefe de Log�stica', 'JL001', 'Responsable de la log�stica y el transporte de productos, incluyendo la cadena de suministro.', 1),
(5, 'Responsable de Innovaci�n', 'RI001', 'Encargado de la identificaci�n de nuevas oportunidades de negocio e implementaci�n de innovaciones tecnol�gicas.', 1),
(5, 'Consultor Externo', 'CE001', 'Profesional externo contratado para brindar asesor�a en �reas espec�ficas como estrategia o procesos.', 1);





---------------select * from Branch office 

INSERT INTO BranchOffice (
    company_id, 
    broff_name, 
    broff_code, 
    broff_address, 
    broff_city, 
    broff_state, 
    broff_country, 
    broff_phone, 
    broff_email, 
    broff_active
)
VALUES
(1, 'Sucursal Centro', 'SC001', 'Calle 50 #34-12', 'Medell�n', 'Antioquia', 'Colombia', '+57 4 3001234', 'centro@innosol.com', 1),
(1, 'Sucursal Norte', 'SN001', 'Carrera 20 #10-32', 'Barranquilla', 'Atl�ntico', 'Colombia', '+57 5 3005678', 'norte@innosol.com', 1),
(2, 'Sucursal Principal', 'SP001', 'Avenida Central 987', 'Caracas', 'Miranda', 'Venezuela', '+58 212 5558901', 'principal@greenenergy.com', 1),
(3, 'Sucursal S�o Paulo', 'SSP001', 'Rua da Paz 456', 'S�o Paulo', 'S�o Paulo', 'Brazil', '+55 11 99876-4321', 'saopaulo@creativemar.com', 1),
(4, 'Sucursal Madrid', 'SM001', 'Avenida de Espa�a 56', 'Madrid', 'Madrid', 'Spain', '+34 91 234 5678', 'madrid@globalfoods.com', 1);


-----------------select * from Company

INSERT INTO Company (
    compa_name, 
    compa_tradename, 
    compa_doctype, 
    compa_docnum, 
    compa_address, 
    compa_city, 
    compa_state, 
    compa_country, 
    compa_industry, 
    compa_phone, 
    compa_email, 
    compa_website, 
    compa_logo, 
    compa_active
)
VALUES
('Innovative Solutions Inc.', 'InnoSol', 'CC', '8002345678', 'Calle 45 #67-89', 'Medell�n', 'Antioquia', 'Colombia', 'Technology', '+57 4 3002345', 'contact@innosol.com', 'https://www.innosol.com', NULL, 1),
('Green Energy Corp.', 'GreenEco', 'NI', '10023456789', 'Av. Libertador 1234', 'Caracas', 'Miranda', 'Venezuela', 'Energy', '+58 212 5557890', 'info@greenenergy.com', 'https://www.greenenergy.com', NULL, 1),
('Creative Marketing Ltda.', 'CreativeMar', 'CE', 'E123456789', 'Rua Boa Vista 101', 'S�o Paulo', 'S�o Paulo', 'Brazil', 'Marketing', '+55 11 91234-5678', 'contact@creativemar.com', 'https://www.creativemar.com', NULL, 1),
('Global Foods Group', 'GlobalFoods', 'PP', 'PP987654321', 'Avenida Central 450', 'Madrid', 'Madrid', 'Spain', 'Food & Beverages', '+34 91 234 5678', 'support@globalfoods.com', 'https://www.globalfoods.com', NULL, 1),
('Tech Innovations Ltd.', 'TechInno', 'OT', 'OT567890123', 'Tech Plaza 32', 'London', 'Greater London', 'UK', 'Technology', '+44 20 7946 1234', 'info@techinnovations.com', 'https://www.techinnovations.com', NULL, 1);



---------------------select * from Cost center
INSERT INTO CostCenter (
    company_id, 
    cosce_parent_id, 
    cosce_code, 
    cosce_name, 
    cosce_description, 
    cosce_budget, 
    cosce_level, 
    cosce_active
)
VALUES
(1, NULL, 'CC001', 'Centro de Costo A', 'Centro de costo principal para operaciones de ventas', 150000.00, 1, 1),
(1, NULL, 'CC002', 'Centro de Costo B', 'Centro de costo para marketing y publicidad', 80000.00, 1, 1),
(1, 1, 'CC003', 'Centro de Costo A1', 'Centro de costo subordinado al Centro de Costo A', 50000.00, 2, 1),
(1, 1, 'CC004', 'Centro de Costo A2', 'Centro de costo subordinado al Centro de Costo A', 45000.00, 2, 1),
(2, NULL, 'CC005', 'Centro de Costo C', 'Centro de costo de investigaci�n y desarrollo', 200000.00, 1, 1),
(2, NULL, 'CC006', 'Centro de Costo D', 'Centro de costo para operaciones de recursos humanos', 120000.00, 1, 1),
(2, 5, 'CC007', 'Centro de Costo C1', 'Centro de costo subordinado al Centro de Costo C', 70000.00, 2, 1),
(3, NULL, 'CC008', 'Centro de Costo E', 'Centro de costo para compras y suministros', 90000.00, 1, 1),
(3, NULL, 'CC009', 'Centro de Costo F', 'Centro de costo para la infraestructura de IT', 130000.00, 1, 1),
(3, 8, 'CC010', 'Centro de Costo E1', 'Centro de costo subordinado al Centro de Costo E', 60000.00, 2, 1)

